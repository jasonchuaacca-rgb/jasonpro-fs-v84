Jason ProAI FS Checking Tool v8.4

JasonPro_v8.4.html and 1_raw_html/ — open in a browser.
2_netlify_pwa/ — drop this folder on Netlify.
3_app_files/ — preview shell files.

v8.4 does the cast before the AI does.
The desk shows a cast log: reported, reperformed, difference, AGREE or DIFFER.
That same log is pasted into every copied prompt.
AGREE is not a finding. DIFFER is HIGH.
Draft unsigned reports stay LOW. OCR spacing is not a finding.

Sign-in: JC / 1005. USER1-USER5 / 1005 view only.
No download buttons inside the tool.

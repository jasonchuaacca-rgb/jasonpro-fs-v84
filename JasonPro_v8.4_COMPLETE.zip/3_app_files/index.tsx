import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="jp-shell">
      <h1 className="jp-visually-hidden">
        Jason ProAI FS Checking Tool v8.4 — private team financial-statement
        workspace
      </h1>
      <div className="jp-export-bar" role="region" aria-label="Download files">
        <a
          className="jp-export-btn"
          href="/deliver/JasonPro_v8.4.html"
          download="JasonPro_v8.4.html"
        >
          Save HTML
        </a>
        <a
          className="jp-export-btn jp-export-btn-primary"
          href="/deliver/JasonPro_v8.4_COMPLETE.zip"
          download="JasonPro_v8.4_COMPLETE.zip"
        >
          Save v8.4 zip
        </a>
      </div>
      <iframe
        title="Jason ProAI FS Checking Tool v8.4"
        src="/tool.html"
        className="jp-frame"
        allow="clipboard-read; clipboard-write; fullscreen"
      />
    </main>
  );
}
